import { S3 } from "@aws-sdk/client-s3";
import { SFNClient, StartExecutionCommand } from "@aws-sdk/client-sfn";

const s3 = new S3();
const sfnClient = new SFNClient();

// Replace with your Step Functions state machine ARN
const stateMachineArn = "arn:aws:states:us-east-2:703671907972:stateMachine:ETL-Customer-Data-Pipeline";

export async function handler(event) {
    console.log("Received Event:", JSON.stringify(event, null, 2));

    let bucketName, objectKey;

    try {
        // Check the event structure (S3 or Step Functions payload)
        if (event.Records && event.Records[0]) {
            // S3 Event
            bucketName = event.Records[0].s3.bucket.name;
            objectKey = decodeURIComponent(event.Records[0].s3.object.key.replace(/\+/g, " "));
        } else if (event.bucketName && event.objectKey) {
            // Step Function Event
            bucketName = event.bucketName;
            objectKey = event.objectKey;
        } else {
            throw new Error("Unsupported event format");
        }

        console.log(`Processing file from bucket: ${bucketName}, key: ${objectKey}`);

        // Fetch the file from S3
        const params = { Bucket: bucketName, Key: objectKey };
        const data = await s3.getObject(params);

        const streamToString = (stream) =>
            new Promise((resolve, reject) => {
                const chunks = [];
                stream.on("data", (chunk) => chunks.push(chunk));
                stream.on("error", reject);
                stream.on("end", () => resolve(Buffer.concat(chunks).toString("utf-8")));
            });

        const fileContent = await streamToString(data.Body);

        // Log the first 100 characters of the file
        console.log("First 100 characters of the file:", fileContent.substring(0, 100));

        // Parse the CSV content
        const lines = fileContent.split("\n");
        const headers = lines[0].split(",");
        const firstNameIndex = headers.indexOf("First Name");

        if (firstNameIndex !== -1) {
            for (let i = 1; i < lines.length; i++) {
                const columns = lines[i].split(",");
                const firstName = columns[firstNameIndex];
                if (firstName) console.log("First Name:", firstName);
            }
        } else {
            console.log("First Name column not found in the CSV file.");
        }

        // Start the Step Function workflow
        const input = JSON.stringify({
            bucketName,
            objectKey,
            filePreview: fileContent.substring(0, 100), // Example: send a preview of the file to Step Functions
        });

        const command = new StartExecutionCommand({
            stateMachineArn,
            input,
        });

        const response = await sfnClient.send(command);
        console.log("Step Function Execution Started:", response);

        return {
            statusCode: 200,
            body: JSON.stringify({
                message: "File processed successfully!",
                executionArn: response.executionArn,
            }),
        };
    } catch (error) {
        console.error("Error processing file:", error);
        return {
            statusCode: 500,
            body: JSON.stringify({
                message: "Error processing file",
                error: error.message,
            }),
        };
    }
}
